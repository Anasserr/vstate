<?php

return [
    'site_title' => 'dashboard',

];
